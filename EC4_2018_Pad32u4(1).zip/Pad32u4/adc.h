/** Definitions for ADC **/

// Prototypes
void adc_init(unsigned char mux);
int adc_read(void);
